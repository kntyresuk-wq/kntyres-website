import {readFile,readdir,mkdir,writeFile,rm,cp} from 'node:fs/promises';
import {build} from 'esbuild';
await rm('dist',{recursive:true,force:true});await mkdir('dist/server',{recursive:true});await mkdir('dist/.openai',{recursive:true});
const assets={};for(const f of await readdir('public')){const b=await readFile('public/'+f);assets['/'+f]={content:b.toString('base64'),type:({html:'text/html; charset=utf-8',js:'text/javascript; charset=utf-8',css:'text/css; charset=utf-8',jpg:'image/jpeg',webp:'image/webp'})[f.split('.').pop()]||'application/octet-stream'}}
await mkdir('.build',{recursive:true});await writeFile('.build/assets.js','export default '+JSON.stringify(assets)+';');
await build({entryPoints:['server/worker.js'],bundle:true,format:'esm',platform:'browser',target:'es2022',outfile:'dist/server/index.js',minify:true});
await cp('.openai/hosting.json','dist/.openai/hosting.json');await cp('drizzle','dist/drizzle',{recursive:true});
console.log('Built KN Tyres platform and inspected migration bundle.');
