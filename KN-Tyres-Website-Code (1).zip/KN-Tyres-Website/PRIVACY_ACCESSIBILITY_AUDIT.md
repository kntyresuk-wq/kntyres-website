# KN Tyres privacy and accessibility implementation — 6 October 2026

## Inspected implementation

Public assets/scripts, Worker headers/routes, authentication, enquiry/booking/sales APIs, schema/migrations and browser storage were inspected. No analytics, marketing scripts, embedded maps/videos, third-party widgets, external fonts, CAPTCHA or online payment processor were found. Google directions/review actions are external hyperlinks. CSP restricts scripts, fonts, images and connections to this origin; external frames are not enabled. Enquiries never dispatch email. Existing optional Resend integration supports password reset and booking notifications only when server credentials are configured.

## Storage

- `__Host-knt`: Secure/HttpOnly/SameSite=Lax login cookie, seven days, token hash in database. Sign-out and approved account deletion revoke access.
- `knt-cookie-preferences`: device-only necessary-storage notice/preference, version/timestamp, expires after 180 days.
- `knt-accessibility`: device-only requested presentation preferences/timestamp, expires after 180 days, resettable without an account.
- No central tracking/consent history is collected. Necessary-only settings accurately expose the current inventory. There is no invented optional-cookie category or consent checkbox.
- Hosting request/security logs and backup locations are infrastructure-controlled: business verification is required in Admin → Privacy & Data. No unverified retention period, registration number or privacy email has been invented.

## Privacy controls

Own-data export uses explicit field lists, excludes credentials and internal notes, and enforces server-side ownership. Authenticated access/deletion requests require password re-entry and are rate-limited. Administrator actions enforce role and Origin checks, version protections and audit history. Approved deletion removes profile/login access; linked business records remain for separate review, with an administrator response required. Active bookings block account-access removal. Reserved administrator accounts are protected.

Retention thresholds are configurable review periods, not silent erasure schedules. Individual review/confirmation and reasons are required. Financial records and sale-linked bookings/enquiries are excluded from routine anonymisation. Holds prevent cleanup. Eligible closed enquiries/cancelled bookings can have personal fields and associated non-financial audit payloads cleared. Dormant/unknown-activity accounts are listed for manual review. Expired authentication/code/rate-limit rows are purged during account-service use. Financial and business audit records remain protected.

The business must verify service terms, processors, transfer safeguards and justified business/financial retention periods and review privacy requests/logs/backups regularly. Policy pages remain accessible during database outages.

## Accessibility implementation and limits

Shared skip link, visible focus, labelled required/optional inputs, native validation errors associated with inputs, focused submission errors, keyboard calendar controls, labelled native modal dialogs, Escape menu behaviour and focus restoration. Existing meaningful photographs and logo have purpose-based alt text. Decorative backgrounds do not become reading content. Carousel controls are labelled and keyboard operable; auto movement pauses on focus/hover and is disabled under system or saved reduced-motion settings. Motion controls also suppress shooting stars, card movement, parallax and animated loaders.

No account is required for text size, high contrast, readable spacing, link underline or reduced-motion preferences. Browser zoom remains allowed. A complete independent WCAG/assistive-technology and contrast audit is not claimed. Browser visual/mobile QA was unavailable in this execution environment; source review, route/render checks and automated API regression tests were completed instead.

## Future changes

Do not add a tracker/embed merely to populate settings. Before adding any optional integration: audit its requests/storage, determine relevant consent category, implement a default-off loader/placeholder and revocation handling, update inventory/policy and test that no optional requests occur before consent. Ordinary external hyperlinks remain available. Provider configuration text does not enable tracking.
