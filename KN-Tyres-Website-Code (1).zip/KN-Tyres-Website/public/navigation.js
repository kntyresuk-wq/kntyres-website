(()=>{
 const nav=document.getElementById('nav'),header=document.getElementById('header');if(!nav)return;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const links=[...nav.querySelectorAll('a')].filter(a=>!a.classList.contains('mobile-menu-brand'));
 function mark(hash){links.forEach(a=>{const u=new URL(a.href);const current=u.pathname===location.pathname&&(hash?u.hash===hash:!u.hash);if(current)a.setAttribute('aria-current',u.hash?'location':'page');else a.removeAttribute('aria-current')})}
 function reveal(target){if((window.KNTMotionReduced?.()||reduced.matches))return;target.classList.remove('nav-arrival');requestAnimationFrame(()=>{target.classList.add('nav-arrival');setTimeout(()=>target.classList.remove('nav-arrival'),700)})}
 links.forEach(a=>a.addEventListener('click',e=>{const u=new URL(a.href);if(e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||u.origin!==location.origin||u.pathname!==location.pathname||!u.hash)return;const target=document.getElementById(u.hash.slice(1));if(!target)return;e.preventDefault();nav.classList.remove('open');const menu=document.querySelector('.menu');if(menu){menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Open navigation')}history.pushState(null,'',u.hash);mark(u.hash);target.scrollIntoView({behavior:(window.KNTMotionReduced?.()||reduced.matches)?'instant':'smooth',block:'start'});reveal(target);if(e.detail===0){target.tabIndex=-1;target.focus({preventScroll:true})}}));
 window.addEventListener('hashchange',()=>mark(location.hash));window.addEventListener('popstate',()=>mark(location.hash));mark(location.hash|| (location.pathname==='/'?'#home':''));
 if(location.hash){const t=document.getElementById(location.hash.slice(1));if(t)reveal(t)}
})();
