# KN Tyres UK Limited — website source folder

Exported 9 October 2026 from published version 17.
Source commit: fab38975f0492d304c0e40359dfb3ed239aad33c

## What is included

- public/: website pages, styling, scripts and original image assets
- server/: authentication, bookings, enquiries, sales, administration and privacy APIs
- db/ and drizzle/: database schema and all four SQL migrations
- scripts/: build script
- tests/: regression tests
- dist/server/index.js: current built Worker with website assets embedded
- package.json and package-lock.json: dependencies
- .openai/hosting.json: original Sites metadata; not a custom-domain configuration
- wrangler.example.toml: optional configuration template for your own Cloudflare Worker

No node_modules, Git history, private runtime settings, API keys, live database dump or customer records are included. The original source is unchanged; only this guide and the optional hosting template were added to the download.

## Build

Install Node.js 24, unzip this archive and open a terminal inside KN-Tyres-Website.

    npm ci
    npm run build

The build outputs dist/server/index.js. Its assets are embedded in the Worker.
This is a backend application, not just HTML. Uploading only public/ to a static
host will not run accounts, bookings, enquiries, administration or sales.
The database binding must be named DB and provide the Cloudflare D1 API.

## Hosting and a custom domain

For hosting on your own Cloudflare account, copy wrangler.example.toml to
wrangler.toml and replace its database_id with the ID of your own D1 database.
The template contains no account credentials and does not create resources.

Initialize ONLY a new empty database by executing these SQL files in order
using your hosting tools: 0000_plain_steel_serpent.sql,
0001_organic_makkari.sql, 0002_square_annihilus.sql,
0003_short_morlocks.sql, all inside drizzle/.
For example, Wrangler's d1 execute command accepts --file=<path> and --remote
for your remote database. Do not rerun these schema-creation files on an
existing database; use a planned migration process instead.

Deploy the Worker with DB attached. For Wrangler use:

    npx wrangler deploy

After deployment, the custom domain can be attached in the Worker dashboard:
Settings → Domains & Routes → Add → Custom Domain.
You need ownership of the domain and an active Cloudflare zone. Attach the
hostnames you intend to use, including www if applicable, and check HTTPS.

Official hosting references:
https://developers.cloudflare.com/d1/get-started/
https://developers.cloudflare.com/workers/configuration/routing/custom-domains/

The build was validated in the original environment. Deployment into your own
hosting account and your domain has not been performed or tested by this export.

## Accounts, administration and existing data

A newly created database starts empty. Existing customer accounts, passwords,
bookings, enquiries and sales do NOT automatically move with the source code.
If you need continuity, arrange a separate secure database migration before
switching the live domain. The current hosted website has not been changed.

The reserved administrator email in the source is parathamuncher6741@gmail.com.
For first-time administrator signup in a fresh database:
1. Generate a long random private setup token locally.
2. Set its SHA-256 hex digest as the Worker secret ADMIN_SETUP_HASH.
3. Open https://YOUR-DOMAIN/create-account#adminSetup=YOUR-PRIVATE-TOKEN.
4. Create the reserved administrator account. Keep the token private and remove
   the setup secret after provisioning; normal administrator login will work.
There is no default password or administrator password in this archive.

Enquiries are database-only and require no email provider. Resend settings are
optional and used only by existing booking-notification/password-reset logic.
Without email configuration, normal signup/login and enquiries still work;
email-based password reset is unavailable and the interface states that.
Review the privacy processor/retention configuration after changing hosting.

## Tests (Node.js 24)

    node tests/platform.test.mjs
    node tests/business.test.mjs
    node tests/enquiry-migration.test.mjs
    node tests/privacy.test.mjs

The tests use disposable in-memory SQLite databases, not live customer data.
