CREATE TABLE `audit` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`actor_id` text NOT NULL,
	`actor_name` text NOT NULL,
	`action` text NOT NULL,
	`entity` text NOT NULL,
	`entity_id` text NOT NULL,
	`before` text DEFAULT '' NOT NULL,
	`after` text DEFAULT '' NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `audit_entity` ON `audit` (`entity`,`entity_id`,`created`);--> statement-breakpoint
CREATE TABLE `blocked_slots` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`date` text NOT NULL,
	`start` integer NOT NULL,
	`end` integer NOT NULL,
	`reason` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `blocked_slots_date` ON `blocked_slots` (`date`);--> statement-breakpoint
CREATE TABLE `bookings` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_id` text NOT NULL,
	`request_id` text NOT NULL,
	`enquiry_id` integer,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`phone` text NOT NULL,
	`registration` text NOT NULL,
	`make` text NOT NULL,
	`model` text NOT NULL,
	`tyre_size` text DEFAULT '' NOT NULL,
	`service` text NOT NULL,
	`date` text NOT NULL,
	`start` integer NOT NULL,
	`duration` integer NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`internal_notes` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'Pending' NOT NULL,
	`created` integer NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`enquiry_id`) REFERENCES `enquiries`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `bookings_request` ON `bookings` (`user_id`,`request_id`);--> statement-breakpoint
CREATE INDEX `bookings_day_status` ON `bookings` (`date`,`status`,`start`);--> statement-breakpoint
CREATE INDEX `bookings_user` ON `bookings` (`user_id`,`created`);--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`kind` text NOT NULL,
	`entity_id` integer NOT NULL,
	`message` text NOT NULL,
	`read` integer DEFAULT 0 NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `notifications_read` ON `notifications` (`read`,`created`);--> statement-breakpoint
CREATE TABLE `sales` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`request_id` text NOT NULL,
	`booking_id` integer,
	`customer` text DEFAULT '' NOT NULL,
	`date` text NOT NULL,
	`time` text NOT NULL,
	`product` text NOT NULL,
	`tyre_size` text DEFAULT '' NOT NULL,
	`quantity` integer NOT NULL,
	`condition` text NOT NULL,
	`brand` text DEFAULT '' NOT NULL,
	`registration` text DEFAULT '' NOT NULL,
	`total_pence` integer NOT NULL,
	`currency` text DEFAULT 'GBP' NOT NULL,
	`payment` text NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`voided` integer DEFAULT 0 NOT NULL,
	`void_reason` text DEFAULT '' NOT NULL,
	`created_by` text NOT NULL,
	`created` integer NOT NULL,
	`updated` integer NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	FOREIGN KEY (`booking_id`) REFERENCES `bookings`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `sales_request` ON `sales` (`request_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `sales_booking` ON `sales` (`booking_id`);--> statement-breakpoint
CREATE INDEX `sales_date_void` ON `sales` (`date`,`voided`);--> statement-breakpoint
CREATE INDEX `sales_product_date` ON `sales` (`product`,`date`);--> statement-breakpoint
CREATE TABLE `settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL,
	`version` integer DEFAULT 1 NOT NULL
);
