PRAGMA defer_foreign_keys=ON;--> statement-breakpoint
CREATE TABLE `__new_enquiries` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_id` text,
	`request_id` text NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`phone` text NOT NULL,
	`registration` text NOT NULL,
	`make` text NOT NULL,
	`model` text NOT NULL,
	`service` text NOT NULL,
	`date` text NOT NULL,
	`time` text NOT NULL,
	`message` text NOT NULL,
	`status` text DEFAULT 'New' NOT NULL,
	`archived` integer DEFAULT 0 NOT NULL,
	`internal_notes` text DEFAULT '' NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`created` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
INSERT INTO `__new_enquiries`("id", "user_id", "request_id", "name", "email", "phone", "registration", "make", "model", "service", "date", "time", "message", "status", "archived", "internal_notes", "version", "created") SELECT "id", "user_id", "request_id", "name", "email", "phone", "registration", "make", "model", "service", "date", "time", "message", CASE WHEN "status"='Submitted' THEN 'New' ELSE "status" END, "archived", '', 1, "created" FROM `enquiries`;--> statement-breakpoint
DROP TABLE `enquiries`;--> statement-breakpoint
ALTER TABLE `__new_enquiries` RENAME TO `enquiries`;--> statement-breakpoint
PRAGMA defer_foreign_keys=OFF;--> statement-breakpoint
CREATE INDEX `enquiries_user` ON `enquiries` (`user_id`,`created`);--> statement-breakpoint
CREATE UNIQUE INDEX `enquiries_request` ON `enquiries` (`user_id`,`request_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `enquiries_guest_request` ON `enquiries` (`request_id`) WHERE "enquiries"."user_id" IS NULL;--> statement-breakpoint
CREATE INDEX `enquiries_filter` ON `enquiries` (`archived`,`status`,`service`);